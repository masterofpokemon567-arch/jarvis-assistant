import os, secrets
from typing import Literal
import httpx
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="JARVIS backend")

class Message(BaseModel):
    role: Literal["user", "model"]
    text: str = Field(max_length=4000)

class Chat(BaseModel):
    messages: list[Message] = Field(min_length=1, max_length=10)
    memory: list[str] = Field(default=[], max_length=100)

@app.post("/chat")
async def chat(body: Chat, authorization: str = Header(default="")):
    token = os.getenv("JARVIS_TOKEN", "")
    if not token or not secrets.compare_digest(authorization.encode(), f"Bearer {token}".encode()):
        raise HTTPException(401, "Unauthorized")
    messages = body.messages
    while messages and messages[0].role != "user":
        messages = messages[1:]
    if not messages:
        raise HTTPException(422, "No user message")
    system = ("You are JARVIS: polite, concise, slightly witty. Reply in English or Hindi to match the user, in plain text. "
              "Admit uncertainty. You have no live web access and cannot perform actions. User-saved facts: " + "; ".join(body.memory)[:3000])
    model = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
    payload = {"systemInstruction": {"parts": [{"text": system}]},
               "contents": [{"role": m.role, "parts": [{"text": m.text}]} for m in messages]}
    try:
        async with httpx.AsyncClient(timeout=50) as client:
            r = await client.post(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                                  headers={"x-goog-api-key": os.getenv("GEMINI_API_KEY", "")}, json=payload)
        r.raise_for_status()
        reply = "".join(p.get("text", "") for p in r.json()["candidates"][0]["content"]["parts"])
    except (httpx.HTTPError, KeyError, IndexError, ValueError):
        raise HTTPException(502, "AI provider failed")
    return {"reply": reply or "No answer."}
