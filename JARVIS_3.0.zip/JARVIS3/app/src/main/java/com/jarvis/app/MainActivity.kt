package com.jarvis.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.*
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    private lateinit var store: Store
    private lateinit var commands: Commands
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private val chat = mutableStateListOf(Msg("Good day. Say “help” to see my commands.", false))
    private var status by mutableStateOf("Tap the core to talk")
    private var listening by mutableStateOf(false)
    private var busy by mutableStateOf(false)
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) { listen() } else { status = "Microphone permission denied" } }

    private fun reply(t: String) {
        chat.add(Msg(t, false)); status = "Tap the core to talk"
        tts.language = Locale.forLanguageTag(store.get("lang").ifEmpty { "en-IN" })
        tts.setSpeechRate(store.get("rate").toFloatOrNull() ?: 1f)
        tts.speak(t.take(3500), TextToSpeech.QUEUE_FLUSH, null, "r")
    }

    private fun send(text: String) {
        if (text.isBlank() || busy) return
        chat.add(Msg(text, true))
        commands.run(text)?.let { reply(it); return }
        val url = store.get("url")
        if (url.isEmpty()) { reply("Add your AI server address in Settings, or say help."); return }
        busy = true; status = "Thinking"
        val history = chat.drop(1); val token = store.get("token"); val memory = store.list("memory")
        thread { val a = askAi(url, token, history, memory); runOnUiThread { busy = false; reply(a) } }
    }

    private fun listen() {
        tts.stop()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { permission.launch(Manifest.permission.RECORD_AUDIO); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status = "No speech service found. Please type."; return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { listening = true; status = "Microphone on. Listening" }
                override fun onResults(r: Bundle?) { listening = false; status = "Tap the core to talk"; send(r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "") }
                override fun onError(e: Int) { listening = false; status = "Did not catch that (error $e). Tap to retry." }
                override fun onEndOfSpeech() { listening = false }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, store.get("lang").ifEmpty { "en-IN" }))
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this); commands = Commands(this, store); tts = TextToSpeech(this) {}
        setContent { MaterialTheme(darkColorScheme(primary = Color(0xFF5FE3FF), background = Color(0xFF06141C))) { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Screen() } } }
    }
    override fun onStop() { super.onStop(); recognizer?.cancel(); listening = false }
    override fun onDestroy() { recognizer?.destroy(); tts.shutdown(); super.onDestroy() }

    @Composable private fun Screen() {
        var tab by remember { mutableIntStateOf(0) }
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(12.dp)) {
            TabRow(tab) { listOf("JARVIS", "Settings").forEachIndexed { i, n -> Tab(tab == i, { tab = i }, text = { Text(n) }) } }
            if (tab == 0) Home() else SettingsTab()
        }
    }

    @Composable private fun ColumnScope.Home() {
        var input by remember { mutableStateOf("") }
        val list = rememberLazyListState()
        LaunchedEffect(chat.size) { list.animateScrollToItem(chat.lastIndex) }
        val pulse by rememberInfiniteTransition(label = "core").animateFloat(1f, 1.15f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "pulse")
        Box(Modifier.align(Alignment.CenterHorizontally).padding(14.dp).size(if (listening) 96.dp * pulse else 96.dp)
            .border(4.dp, MaterialTheme.colorScheme.primary, CircleShape).clickable(enabled = !busy) { listen() }, Alignment.Center) {
            if (busy) CircularProgressIndicator() else Text("J", fontSize = 36.sp, color = MaterialTheme.colorScheme.primary)
        }
        Text(status, Modifier.align(Alignment.CenterHorizontally))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), list) {
            items(chat) { m -> Text((if (m.user) "You: " else "JARVIS: ") + m.text, Modifier.padding(vertical = 6.dp), color = if (m.user) MaterialTheme.colorScheme.primary else Color.White) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Message JARVIS") })
            TextButton({ send(input); input = "" }, enabled = !busy) { Text("Send") }
        }
        TextButton({ tts.stop() }) { Text("Stop speaking") }
    }

    @Composable private fun SettingsTab() {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            listOf("url" to "AI server address (https://…)", "token" to "Server password", "lang" to "Language (en-IN or hi-IN)", "rate" to "Speech speed (0.5 to 2)").forEach { (key, label) ->
                var v by remember { mutableStateOf(store.get(key)) }
                OutlinedTextField(v, { v = it; store.put(key, it.trim()) }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text(label) }, singleLine = true)
            }
            Text("Changes save automatically. The microphone is used only after you tap the core.", Modifier.padding(vertical = 12.dp))
            Button({ chat.clear(); chat.add(Msg("Conversation cleared.", false)) }) { Text("Clear conversation") }
            Button({ store.set("memory", emptyList()); store.set("tasks", emptyList()) }) { Text("Erase memory and tasks") }
        }
    }
}
