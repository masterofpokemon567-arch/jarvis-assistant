package com.jarvis.app

import android.content.*
import android.hardware.camera2.*
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import java.text.DateFormat
import java.util.Date

/** Device actions. Returns a reply, or null so the question goes to the AI. */
class Commands(private val c: Context, private val store: Store) {
    private fun go(i: Intent, ok: String) = try { c.startActivity(i); ok } catch (e: Exception) { "This phone could not open that." }
    private fun view(u: String, ok: String) = go(Intent(Intent.ACTION_VIEW, Uri.parse(u)), ok)

    fun run(raw: String): String? {
        val q = raw.trim().replace(Regex("^(hey )?jarvis[, ]*", RegexOption.IGNORE_CASE), "").trimEnd('.', '?', '!')
        fun m(p: String) = Regex(p, RegexOption.IGNORE_CASE).matchEntire(q)?.groupValues
        if (m("help") != null) return "Try: time, date, battery, open WhatsApp, open camera, torch on, volume up, wifi settings, bluetooth settings, call 100, message 98..., navigate to airport, search cricket, set timer 5 minutes, set alarm 6:30, share hello, add task study, done 1, remember I like tea, forget everything."
        if (m("(what('s| is) the )?time|what time is it") != null) return "The time is " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())
        if (m("(what('s| is) )?(the |today's )?date( today)?|what day is it") != null) return "Today is " + DateFormat.getDateInstance(DateFormat.FULL).format(Date())
        if (m("battery( level| status)?") != null) return "Battery is at ${c.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%."
        m("(?:torch|flashlight) (on|off)")?.let { g ->
            return try {
                val cm = c.getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                cm.setTorchMode(id, g[1].equals("on", true)); "Torch ${g[1].lowercase()}."
            } catch (e: Exception) { "The torch is unavailable." }
        }
        m("volume (up|down)")?.let { g ->
            c.getSystemService(AudioManager::class.java).adjustStreamVolume(AudioManager.STREAM_MUSIC,
                if (g[1].equals("up", true)) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            return "Volume ${g[1].lowercase()}."
        }
        if (m("open (the )?camera") != null) return go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "Opening camera.")
        m("(?:open )?(wifi|wi-fi|bluetooth) settings")?.let { g ->
            return go(Intent(if (g[1].startsWith("b", true)) Settings.ACTION_BLUETOOTH_SETTINGS else Settings.ACTION_WIFI_SETTINGS), "Opening settings.")
        }
        m("call (\\+?[\\d -]{3,})")?.let { return go(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(it[1]))), "Number ready. Press call to confirm.") }
        m("(?:message|text|sms) (\\+?[\\d -]{3,})")?.let { return go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(it[1]))), "Write and send your message.") }
        m("(?:navigate|directions) to (.+)")?.let { return view("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(it[1]), "Opening directions.") }
        m("(?:search(?: for)?|google) (.+)")?.let { return view("https://www.google.com/search?q=" + Uri.encode(it[1]), "Searching.") }
        m("open (?:website )?([\\w-]+(?:\\.[\\w-]+)+\\S*)")?.let { return view("https://" + it[1], "Opening website.") }
        m("open (.+)")?.let { g ->
            val pm = c.packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val app = apps.firstOrNull { it.loadLabel(pm).toString().equals(g[1], true) }
            val i = app?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) } ?: return "I could not find an app called ${g[1]}."
            return go(i, "Opening ${g[1]}.")
        }
        m("(?:set )?(?:a )?timer (?:for )?(\\d{1,4}) ?(sec|min|hour)\\w*")?.let { g ->
            val s = g[1].toInt() * when (g[2].lowercase()) { "sec" -> 1; "min" -> 60; else -> 3600 }
            if (s !in 1..86400) return "Timers can be 1 second to 24 hours."
            return go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s), "Sending timer to your clock app.")
        }
        m("(?:set )?(?:an )?alarm (?:for |at )?(\\d{1,2})(?:[:.](\\d\\d))? ?(am|pm)?")?.let { g ->
            var h = g[1].toInt(); val min = g[2].toIntOrNull() ?: 0; val ap = g[3].lowercase()
            if (min > 59 || h > 23 || (ap.isNotEmpty() && h !in 1..12)) return "That time is not valid."
            if (ap.isNotEmpty()) h = h % 12 + if (ap == "pm") 12 else 0
            return go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, min),
                "Sending alarm for %02d:%02d to your clock app.".format(h, min))
        }
        m("share (.+)")?.let { return go(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, it[1]), "Share"), "Choose where to share.") }
        m("add (?:a )?task (.+)")?.let { store.add("tasks", it[1]); return "Task added." }
        m("(?:done|delete task) (\\d{1,4})")?.let { return if (store.remove("tasks", it[1].toInt() - 1)) "Task completed." else "No task has that number." }
        if (m("(show )?(my )?tasks") != null) return store.list("tasks").mapIndexed { i, t -> "${i + 1}. $t" }.joinToString("\n").ifEmpty { "No pending tasks." }
        m("remember (?:that )?(.+)")?.let { store.add("memory", it[1]); return "I will remember that." }
        if (m("what do you remember") != null) return store.list("memory").joinToString("\n").ifEmpty { "Nothing saved." }
        if (m("forget everything") != null) { store.set("memory", emptyList()); return "Memory erased." }
        return null
    }
}
