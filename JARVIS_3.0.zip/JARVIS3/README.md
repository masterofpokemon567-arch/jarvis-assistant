# JARVIS 3.0 (stage 1)
Status: Android source has NOT been compiled or tested on a device.

## Build the APK
Option A: open this folder in Android Studio, then Build > Build APK.
Option B: upload all files (including the hidden .github folder) to a GitHub repository root. Open Actions > Build APK, and download the jarvis-apk artifact. Unzip and install on your phone (allow installs from that source).

## AI backend
Local check: `cd backend && pip install -r requirements.txt`, set GEMINI_API_KEY and JARVIS_TOKEN, run `uvicorn main:app`.
For the phone, deploy to an HTTPS Python host with start command `uvicorn main:app --host 0.0.0.0 --port $PORT` and the same variables. Use a long random token. Enter the address and token in the app's Settings. GEMINI_MODEL is optional.

## Test checklist
help, time, battery, torch on/off, volume up, open camera, open <app>, call 100 (dialer only), set timer 1 minute, set alarm 6:30 am, add task, restart app and show tasks, voice in en-IN and hi-IN, one AI question, wrong token shows error 401.

## Later stages
Wake phrase, web search with citations, weather, calendar, routines, notifications, camera/OCR, task engine, smart home, Windows companion, encrypted storage, app login. Commands are English only. Chat history is not saved after closing.
