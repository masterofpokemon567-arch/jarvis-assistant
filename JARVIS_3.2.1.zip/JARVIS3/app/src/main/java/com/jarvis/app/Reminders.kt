package com.jarvis.app

import android.app.*
import android.content.*

/** Posts a JARVIS notification when a scheduled reminder fires. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("reminders", "Reminders", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(System.currentTimeMillis().toInt(), Notification.Builder(c, "reminders")
            .setSmallIcon(R.drawable.icon).setContentTitle("JARVIS reminder")
            .setContentText(i.getStringExtra("text")).setContentIntent(open).setAutoCancel(true).build())
    }
}

/** Approximate timing: Android may delay it to save battery. */
fun scheduleReminder(c: Context, minutes: Int, text: String) {
    val id = System.currentTimeMillis().toInt()
    val p = PendingIntent.getBroadcast(c, id, Intent(c, ReminderReceiver::class.java).putExtra("text", text), PendingIntent.FLAG_IMMUTABLE)
    c.getSystemService(AlarmManager::class.java)
        .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + minutes * 60000L, p)
}
