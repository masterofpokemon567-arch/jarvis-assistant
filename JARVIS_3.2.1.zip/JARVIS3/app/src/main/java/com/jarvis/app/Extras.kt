package com.jarvis.app

import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder

/** Arithmetic with + - * / and brackets. Returns null if invalid. */
fun calculate(s: String): Double? {
    val k = Regex("\\d*\\.?\\d+|\\S").findAll(s).map { it.value }.toList()
    var i = 0
    var depth = 0
    fun expr(level: Int): Double {
        require(++depth < 200)
        var v: Double
        if (level == 2) {
            val t = k[i++]
            v = when (t) {
                "-" -> -expr(2)
                "(" -> expr(0).also { require(k[i++] == ")") }
                else -> t.toDouble()
            }
        } else {
            v = expr(level + 1)
            val ops = if (level == 0) listOf("+", "-") else listOf("*", "/")
            while (i < k.size && k[i] in ops) {
                val op = k[i++]
                val b = expr(level + 1)
                v = when (op) { "+" -> v + b; "-" -> v - b; "*" -> v * b; else -> v / b }
            }
        }
        depth--
        return v
    }
    return try { val r = expr(0); if (i == k.size && r.isFinite()) r else null } catch (e: Exception) { null }
}

/** Current weather from Open-Meteo. Run off the main thread. */
fun weather(city: String): String = try {
    fun get(u: String): JSONObject {
        val c = URL(u).openConnection()
        c.connectTimeout = 15000; c.readTimeout = 15000
        return JSONObject(c.getInputStream().bufferedReader().readText())
    }
    val g = get("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + URLEncoder.encode(city, "UTF-8")).getJSONArray("results").getJSONObject(0)
    val w = get("https://api.open-meteo.com/v1/forecast?latitude=${g.getDouble("latitude")}&longitude=${g.getDouble("longitude")}&current=temperature_2m,relative_humidity_2m&daily=precipitation_probability_max&timezone=auto&forecast_days=1")
    val now = w.getJSONObject("current")
    "${g.getString("name")}: ${now.getDouble("temperature_2m")}°C, humidity ${now.getInt("relative_humidity_2m")}%, rain chance ${w.getJSONObject("daily").getJSONArray("precipitation_probability_max").get(0)}% (Open-Meteo)."
} catch (e: Exception) { "I could not get weather for $city." }
