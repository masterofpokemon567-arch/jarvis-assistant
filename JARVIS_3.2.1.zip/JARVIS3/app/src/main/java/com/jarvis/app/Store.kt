package com.jarvis.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Private on-device storage. */
class Store(c: Context) {
    private val p = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun get(k: String) = p.getString(k, "") ?: ""
    fun put(k: String, v: String) = p.edit().putString(k, v).apply()
    fun list(k: String): List<String> { val a = JSONArray(get(k).ifEmpty { "[]" }); return List(a.length()) { a.getString(it) } }
    fun set(k: String, v: List<String>) = put(k, JSONArray(v).toString())
    fun add(k: String, v: String) = set(k, list(k) + v)
    fun remove(k: String, i: Int): Boolean { val l = list(k); if (i !in l.indices) return false; set(k, l.filterIndexed { n, _ -> n != i }); return true }
}

data class Msg(val text: String, val user: Boolean)

/** Calls your own backend, which holds the AI key. Run off the main thread. */
fun askAi(url: String, token: String, history: List<Msg>, memory: List<String>): String = try {
    require(url.startsWith("https://"))
    val body = JSONObject().put("memory", JSONArray(memory)).put("messages",
        JSONArray(history.takeLast(10).map { JSONObject().put("role", if (it.user) "user" else "model").put("text", it.text.take(4000)) }))
    val h = URL(url.trimEnd('/') + "/chat").openConnection() as HttpURLConnection
    h.requestMethod = "POST"; h.doOutput = true; h.connectTimeout = 15000; h.readTimeout = 60000
    h.setRequestProperty("Content-Type", "application/json"); h.setRequestProperty("Authorization", "Bearer $token")
    h.outputStream.use { it.write(body.toString().toByteArray()) }
    if (h.responseCode == 200) JSONObject(h.inputStream.bufferedReader().readText()).getString("reply")
    else "The server returned error ${h.responseCode}."
} catch (e: Exception) { "I could not reach the AI server. Check the https address in Settings and your internet." }
