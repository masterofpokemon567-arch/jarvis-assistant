package com.jarvis.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Build
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import android.speech.tts.UtteranceProgressListener
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.*
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    private lateinit var store: Store
    private lateinit var commands: Commands
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private val chat = mutableStateListOf(Msg("Good day. Say “help” to see my commands.", false))
    private var status by mutableStateOf("Tap the core to talk")
    private var listening by mutableStateOf(false)
    private var busy by mutableStateOf(false)
    private val handler = Handler(Looper.getMainLooper())
    private var active = false
    private val wakeRun = Runnable { if (active && !listening && !busy && !tts.isSpeaking) listen(false) }
    private fun scheduleWake() {
        handler.removeCallbacks(wakeRun)
        if (active && store.get("wake").equals("on", true) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) handler.postDelayed(wakeRun, 1000)
    }
    private fun saveChat() = store.set("chat", chat.takeLast(60).map { (if (it.user) "u" else "j") + it.text })
    private fun fetch(work: () -> String) {
        busy = true; status = "Working"; handler.removeCallbacks(wakeRun); recognizer?.cancel(); listening = false
        thread { val a = work(); runOnUiThread { busy = false; reply(a) } }
    }
    private var pending by mutableStateOf<Pair<String, List<String>>?>(null)
    private val notifyPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        reply(if (ok) "Notifications allowed. Send your reminder again." else "Notification permission denied.")
    }
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                busy = true; status = "Reading text"
                val reader = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
                reader.process(InputImage.fromFilePath(this, uri))
                    .addOnSuccessListener { busy = false; reply(if (it.text.isBlank()) "No text found." else "Scanned text:\n" + it.text) }
                    .addOnFailureListener { busy = false; reply("I could not read that image.") }
                    .addOnCompleteListener { reader.close() }
            } catch (e: Exception) { busy = false; reply("I could not open that image.") }
        }
    }
    private fun runRoutine(steps: List<String>) {
        // Stop after a step that opens another screen, so screens do not pile up.
        val results = mutableListOf<String>()
        for (step in steps) {
            val result = commands.run(step) ?: "Not supported in routines."
            results.add("$step: $result")
            if (Regex("(open|call|message|text|sms|navigate|directions|search|google|share|set|remind me|add event|add an event|create event|create an event|wifi|wi-fi|bluetooth)\\b.*", RegexOption.IGNORE_CASE).matches(step)) break
        }
        reply(results.joinToString("\n"))
    }
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) { listen() } else { status = "Microphone permission denied" } }

    private fun reply(t: String) {
        chat.add(Msg(t, false)); status = "Tap the core to talk"
        tts.language = Locale.forLanguageTag(store.get("lang").ifEmpty { "en-IN" })
        tts.setSpeechRate(store.get("rate").toFloatOrNull() ?: 1f)
        saveChat()
        if (tts.speak(t.take(3500), TextToSpeech.QUEUE_FLUSH, null, "r") != TextToSpeech.SUCCESS) scheduleWake()
    }

    private fun send(text: String) {
        if (text.isBlank() || busy) return
        chat.add(Msg(text, true)); saveChat()
        val q = text.trim().replace(Regex("^(hey )?jarvis[, ]*", RegexOption.IGNORE_CASE), "").trimEnd('.', '?', '!')
        if (q.equals("scan text", true)) { recognizer?.cancel(); listening = false; picker.launch("image/*"); return }
        if (q.startsWith("notify me", true) && Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifyPermission.launch(Manifest.permission.POST_NOTIFICATIONS); return
        }
        if (q.startsWith("run ", true)) {
            val name = q.drop(4).trim().lowercase()
            val routine = store.list("routines").firstOrNull { it.startsWith("$name|") }
            if (routine == null) reply("No routine has that name.")
            else { pending = name to routine.substringAfter("|").split(";").map { it.trim() }.filter { it.isNotEmpty() }; status = "Confirm the routine on screen" }
            return
        }
        val city = store.get("city")
        Regex("weather(?: (?:in|at) (.+))?", RegexOption.IGNORE_CASE).matchEntire(q)?.let {
            val place = it.groupValues[1].ifEmpty { city }
            if (place.isEmpty()) reply("Say weather in Delhi, or set your city in Settings.") else fetch { weather(place) }
            return
        }
        if (q.equals("morning briefing", true)) {
            val head = listOfNotNull(commands.run("date"), commands.run("battery"), "Tasks:\n" + commands.run("tasks")).joinToString("\n")
            if (city.isEmpty()) reply(head) else fetch { head + "\n" + weather(city) }
            return
        }
        commands.run(text)?.let { reply(it); return }
        val url = store.get("url")
        if (url.isEmpty()) { reply("Add your AI server address in Settings, or say help."); return }
        val history = chat.drop(1); val token = store.get("token"); val memory = store.list("memory")
        fetch { askAi(url, token, history, memory) }
    }

    private fun listen(manual: Boolean = true) {
        handler.removeCallbacks(wakeRun)
        tts.stop()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { permission.launch(Manifest.permission.RECORD_AUDIO); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status = "No speech service found. Please type."; return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { listening = true; status = if (manual) "Microphone on. Listening" else "Microphone on. Say Jarvis" }
                override fun onResults(r: Bundle?) {
                    listening = false; status = "Tap the core to talk"
                    val heard = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    val called = Regex("jarvis|जार्विस", RegexOption.IGNORE_CASE).find(heard)
                    if (manual) send(heard) else if (called != null) send(heard.substring(called.range.last + 1).trim(' ', ',').ifEmpty { "help" })
                    if (!busy && !tts.isSpeaking) scheduleWake()
                }
                override fun onError(e: Int) {
                    listening = false; status = if (manual) "Did not catch that (error $e). Tap to retry." else "Tap the core to talk"
                    if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) scheduleWake()
                }
                override fun onEndOfSpeech() { listening = false }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, store.get("lang").ifEmpty { "en-IN" }))
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this); commands = Commands(this, store); tts = TextToSpeech(this) {}
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { runOnUiThread { scheduleWake() } }
            @Deprecated("Required by the platform")
            override fun onError(id: String?) { runOnUiThread { scheduleWake() } }
        })
        store.list("chat").takeIf { it.isNotEmpty() }?.let { saved -> chat.clear(); chat.addAll(saved.map { Msg(it.drop(1), it.startsWith("u")) }) }
        setContent { MaterialTheme(darkColorScheme(primary = Color(0xFF5FE3FF), background = Color(0xFF06141C))) { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Screen() } } }
    }
    override fun onResume() { super.onResume(); active = true; scheduleWake() }
    override fun onStop() { super.onStop(); active = false; handler.removeCallbacks(wakeRun); recognizer?.cancel(); listening = false }
    override fun onDestroy() { recognizer?.destroy(); tts.shutdown(); super.onDestroy() }

    @Composable private fun Screen() {
        var tab by remember { mutableIntStateOf(0) }
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(12.dp)) {
            TabRow(tab) { listOf("JARVIS", "Settings").forEachIndexed { i, n -> Tab(tab == i, { tab = i }, text = { Text(n) }) } }
            if (tab == 0) Home() else SettingsTab()
            pending?.let { (name, steps) ->
                AlertDialog(onDismissRequest = { pending = null; status = "Tap the core to talk" },
                    title = { Text("Run $name?") }, text = { Text(steps.joinToString("\n")) },
                    confirmButton = { TextButton({ pending = null; runRoutine(steps) }) { Text("Run") } },
                    dismissButton = { TextButton({ pending = null; status = "Tap the core to talk" }) { Text("Cancel") } })
            }
            LaunchedEffect(tab) { if (tab == 0) scheduleWake() else { handler.removeCallbacks(wakeRun); recognizer?.cancel(); listening = false } }
        }
    }

    @Composable private fun ColumnScope.Home() {
        var input by remember { mutableStateOf("") }
        val list = rememberLazyListState()
        LaunchedEffect(chat.size) { list.animateScrollToItem(chat.lastIndex) }
        val pulse by rememberInfiniteTransition(label = "core").animateFloat(1f, 1.15f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "pulse")
        Box(Modifier.align(Alignment.CenterHorizontally).padding(14.dp).size(if (listening) 96.dp * pulse else 96.dp)
            .border(4.dp, MaterialTheme.colorScheme.primary, CircleShape).clickable(enabled = !busy) { listen() }, Alignment.Center) {
            if (busy) CircularProgressIndicator() else Text("J", fontSize = 36.sp, color = MaterialTheme.colorScheme.primary)
        }
        Text(status, Modifier.align(Alignment.CenterHorizontally))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), list) {
            items(chat) { m -> Text((if (m.user) "You: " else "JARVIS: ") + m.text, Modifier.padding(vertical = 6.dp), color = if (m.user) MaterialTheme.colorScheme.primary else Color.White) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Message JARVIS") })
            TextButton({ send(input); input = "" }, enabled = !busy) { Text("Send") }
        }
        TextButton({ tts.stop(); scheduleWake() }) { Text("Stop speaking") }
    }

    @Composable private fun SettingsTab() {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            listOf("url" to "AI server address (https://…)", "token" to "Server password", "lang" to "Language (en-IN or hi-IN)", "rate" to "Speech speed (0.5 to 2)", "city" to "Your city (for weather)", "wake" to "Wake word while app is open (on or off)").forEach { (key, label) ->
                var v by remember { mutableStateOf(store.get(key)) }
                OutlinedTextField(v, { v = it; store.put(key, it.trim()) }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text(label) }, singleLine = true)
            }
            Text("Changes save automatically. The microphone is used when you tap the core, or while the app is open if the wake word is on.", Modifier.padding(vertical = 12.dp))
            Button({ chat.clear(); chat.add(Msg("Conversation cleared.", false)); saveChat() }) { Text("Clear conversation") }
            Button({ store.set("memory", emptyList()); store.set("tasks", emptyList()); store.set("notes", emptyList()); store.set("routines", emptyList()) }) { Text("Erase memory, tasks, notes and routines") }
        }
    }
}
